# client-apps
This is a collection of apps built using the Geniuslink Api.

##Geniuslink Chrome Extension
See the [Documentation](https://github.com/georiot/client-apps/blob/master/ChromeExtension/README.md) 

Download the [Geniuslink Chrome Extension](https://chrome.google.com/webstore/detail/geniuslink-intelligent-li/fgoilnlnleemcedbmhoalpmhkefdppbm)
