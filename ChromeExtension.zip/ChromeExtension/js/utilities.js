function localStorageHasValue(val) {
    return localStorage[val] != null && localStorage != '';
}