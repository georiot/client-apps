document.addEventListener('DOMContentLoaded', function () {
    createGeniusCurrentTab();
});